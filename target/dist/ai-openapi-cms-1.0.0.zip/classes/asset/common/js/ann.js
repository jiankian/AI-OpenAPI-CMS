var app = new Object();
app.name = "安浪人工智能";
app.version = "1.0.0Beta";